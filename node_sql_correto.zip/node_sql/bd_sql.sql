create database teste34;

use teste34;

create table teste(
id int primary key auto_increment,
nome varchar(120) not null
);

select * from teste;
